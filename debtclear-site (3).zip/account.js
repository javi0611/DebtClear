/* Account page */
(function(){
"use strict";
const DC = window.DC; const $ = s => document.querySelector(s);
DC.ready.then(u => {
  if (!u) return;
  $("#acctGuest").hidden = true; $("#acctUser").hidden = false;
  $("#acctLead").textContent = "Your plan saves to your account automatically.";
  $("#acctEmail").textContent = u.email || "";
  const nm = $("#displayName"); nm.value = (u.user_metadata && (u.user_metadata.full_name || u.user_metadata.name)) || "";
  setTimeout(() => { if (DC.app && DC.app.state.displayName) nm.value = DC.app.state.displayName; }, 1500);
  $("#nameForm").onsubmit = async e => { e.preventDefault(); const v = nm.value.trim(); if (DC.app) DC.app.displayName = v; await DC.sb.auth.updateUser({ data: { full_name: v } }); $("#pwMsg").textContent = "Name saved."; };
  $("#pwForm").onsubmit = async e => { e.preventDefault(); const { error } = await DC.sb.auth.updateUser({ password: $("#newPw").value }); $("#pwMsg").textContent = error ? DC.friendlyError(error) : "Password changed."; if (!error) $("#newPw").value = ""; };
  $("#signOut").onclick = () => DC.signOut();
});
})();
