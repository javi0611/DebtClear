/* DebtClear connection settings. These values are meant to be public (the database rules do the protecting). */
window.DEBTCLEAR_CONFIG = {
  supabaseUrl: "https://fgkrsjeewkkmssnkifit.supabase.co",
  supabaseKey: "sb_publishable_X8gogT0VFlKV02CvY1ncnA_nYaDSr-a",
  // Set to true after turning on the Google provider in Supabase (Authentication → Sign In / Providers → Google)
  googleEnabled: false
};
