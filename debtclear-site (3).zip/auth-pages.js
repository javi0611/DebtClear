/* Sign in, join, and reset pages */
(function(){
"use strict";
const DC = window.DC, sb = DC.sb;
const $ = s => document.querySelector(s);
const params = new URLSearchParams(location.search);
const nextPage = /^[a-z-]+\.html$/.test(params.get("next") || "") ? params.get("next") : "planner.html";
const here = location.pathname.split("/").pop();
function msg(id, text, ok){ const el = $(id); if (!el) return; el.textContent = text; el.className = "msg " + (ok ? "ok" : "bad"); }
function busy(on){ const b = $("#submitBtn"); if (b){ b.disabled = on; b.dataset.label = b.dataset.label || b.textContent; b.textContent = on ? "One moment…" : b.dataset.label; } }
if (!sb){ msg("#msg", "The sign-in service couldn't load. Refresh the page and try again."); return; }

// Already signed in? Skip the form (except on the reset page while setting a new password).
DC.ready.then(u => { if (u && here !== "reset.html") location.replace(nextPage); });

const g = $("#googleBtn");
if (g && !(window.DEBTCLEAR_CONFIG || {}).googleEnabled){ g.hidden = true; const or = document.querySelector(".or"); if (or) or.hidden = true; }
if (g) g.onclick = async () => {
  g.disabled = true;
  const { error } = await sb.auth.signInWithOAuth({ provider: "google", options: { redirectTo: location.origin + location.pathname.replace(/[^/]*$/, "") + nextPage } });
  if (error){ g.disabled = false; msg("#msg", DC.friendlyError(error)); }
};

const si = $("#signinForm");
if (si) si.onsubmit = async e => {
  e.preventDefault(); busy(true); msg("#msg", "");
  const { error } = await sb.auth.signInWithPassword({ email: $("#email").value.trim(), password: $("#password").value });
  if (error){ busy(false); msg("#msg", DC.friendlyError(error)); return; }
  location.replace(nextPage);
};

const jf = $("#joinForm");
if (jf) jf.onsubmit = async e => {
  e.preventDefault(); busy(true); msg("#msg", "");
  const email = $("#email").value.trim();
  const { data, error } = await sb.auth.signUp({ email, password: $("#password").value, options: { data: { full_name: $("#name").value.trim() }, emailRedirectTo: location.origin + location.pathname.replace(/[^/]*$/, "") + "planner.html" } });
  if (error){ busy(false); msg("#msg", DC.friendlyError(error)); return; }
  if (data.session){ location.replace("planner.html"); return; }
  busy(false); jf.querySelectorAll("input,button").forEach(x => x.disabled = true);
  msg("#msg", "Almost there. We sent a confirmation link to " + email + ". Open it, then come back and sign in.", true);
};

const rf = $("#resetForm");
if (rf) rf.onsubmit = async e => {
  e.preventDefault(); busy(true); msg("#msg", "");
  const email = $("#email").value.trim();
  const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname.replace(/[^/]*$/, "") + "reset.html" });
  busy(false);
  if (error){ msg("#msg", DC.friendlyError(error)); return; }
  msg("#msg", "If there's an account for " + email + ", a reset link is on its way.", true);
};

// Arriving from the email link: Supabase fires PASSWORD_RECOVERY once the session is picked up.
if (here === "reset.html"){
  const showSet = () => { $("#askStep").hidden = true; $("#setStep").hidden = false; };
  if (location.hash.includes("type=recovery")) showSet();
  sb.auth.onAuthStateChange(evt => { if (evt === "PASSWORD_RECOVERY") showSet(); });
  $("#setForm").onsubmit = async e => {
    e.preventDefault(); msg("#msg2", "");
    const { error } = await sb.auth.updateUser({ password: $("#newPw").value });
    if (error){ msg("#msg2", DC.friendlyError(error)); return; }
    msg("#msg2", "Password saved. Taking you to your plan…", true); setTimeout(() => location.replace("planner.html"), 900);
  };
}
})();
