/* DebtClear auth: one shared Supabase client, the account menu in the nav, and helpers the pages use. */
(function(){
"use strict";
const cfg = window.DEBTCLEAR_CONFIG || {};
let client = null;
try { client = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } }); } catch (e) { console.warn("Supabase client failed to start", e); }

const DC = window.DC = window.DC || {};
DC.sb = client;
DC.user = null;
DC.ready = (async () => {
  if (!client) return null;
  try { const { data } = await client.auth.getSession(); DC.user = data.session ? data.session.user : null; } catch (e) { DC.user = null; }
  return DC.user;
})();

DC.friendlyError = function(err){
  const m = (err && err.message || String(err || "")).toLowerCase();
  if (m.includes("invalid login")) return "That email and password don't match.";
  if (m.includes("email not confirmed")) return "Check your inbox and confirm your email first.";
  if (m.includes("already registered") || m.includes("already been registered")) return "There's already an account with that email. Try signing in.";
  if (m.includes("password should be")) return "Use a password with at least 6 characters.";
  if (m.includes("rate limit") || m.includes("too many")) return "Too many tries. Wait a minute and try again.";
  if (m.includes("provider is not enabled") || m.includes("unsupported provider")) return "Google sign-in isn't turned on yet. Use email and password for now.";
  if (m.includes("valid email")) return "Enter a valid email address.";
  return (err && err.message) || "Something went wrong. Try again.";
};

DC.signOut = async function(){ if (client) await client.auth.signOut(); try { localStorage.removeItem("debtclear-cache"); } catch (e) {} location.href = "index.html"; };

/* Nav account area */
function renderNav(){
  const slot = document.getElementById("navAccount"); if (!slot) return;
  if (DC.user){
    const name = (DC.user.user_metadata && (DC.user.user_metadata.full_name || DC.user.user_metadata.name)) || DC.user.email || "Account";
    slot.innerHTML = '<a href="account.html" class="acct" title="' + esc(DC.user.email || "") + '"><span class="avatar">' + esc(name.trim()[0].toUpperCase()) + '</span><span class="acct-name">' + esc(name.split("@")[0]) + '</span></a>';
  } else {
    slot.innerHTML = '<a href="signin.html" class="btn small ghost">Sign in</a><a href="join.html" class="btn small primary">Join free</a>';
  }
}
function esc(s){ return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
DC.ready.then(renderNav);
if (client) client.auth.onAuthStateChange((_evt, session) => { DC.user = session ? session.user : null; renderNav(); });
})();
