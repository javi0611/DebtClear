/* DebtClear v3 — shared logic for every page. Guests: browser storage. Signed in: Supabase. */
(function(){
"use strict";
const DC = window.DC = window.DC || {};
const GUEST_KEY = "debtclear-guest", CACHE_KEY = "debtclear-cache";
let KEY = GUEST_KEY;
const $ = (s, r) => (r || document).querySelector(s);
const pad = n => String(n).padStart(2, "0");
const iso = d => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const parseISO = s => { const [y, m, d] = String(s).split("-").map(Number); return (y && m && d) ? new Date(y, m - 1, d) : null; };
const addDays = (d, k) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + k);
const dim = (y, m) => new Date(y, m + 1, 0).getDate();
const onDay = (y, m, day) => new Date(y, m, Math.min(Math.max(1, day), dim(y, m)));
const T0 = new Date(); const TODAY = new Date(T0.getFullYear(), T0.getMonth(), T0.getDate());
const uid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === "x" ? r : (r & 3 | 8)).toString(16); });
const n = v => { const x = parseFloat(v); return isFinite(x) ? x : 0; };
const usd0 = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
const usd2 = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2 });
const money = v => usd0.format(Math.round(v));
const money2 = v => usd2.format(Math.round(v * 100) / 100);
const mLabel = d => d.toLocaleDateString("en-US", { month: "short", year: "numeric" });
const dLabel = d => d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
const short = d => d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
function nextOnDay(day){ let d = onDay(TODAY.getFullYear(), TODAY.getMonth(), day); if (d < TODAY) d = onDay(TODAY.getFullYear(), TODAY.getMonth() + 1, day); return d; }
function nextWeekday(wd){ const d = new Date(TODAY); while (d.getDay() !== wd) d.setDate(d.getDate() + 1); return d; }

/* ---------- state ---------- */
function exampleState(){
  const s = blankState(); s.example = true; s.extra = 200; s.updated = 0;
  s.debts = [
    { id: uid(), name: "Visa card", balance: 4200, start: 5100, apr: 24.99, min: 120, due: 12 },
    { id: uid(), name: "Store card", balance: 950, start: 1400, apr: 29.99, min: 40, due: 22 },
    { id: uid(), name: "Car loan", balance: 11800, start: 14500, apr: 7.4, min: 310, due: 5 },
    { id: uid(), name: "Student loan", balance: 8600, start: 9200, apr: 5.5, min: 115, due: 28 } ];
  s.pays = [ { id: uid(), name: "Main job", amount: 1450, freq: "biweekly", date: iso(nextWeekday(5)), days: "1, 15", spend: 300 } ];
  s.bills = [ { id: uid(), name: "Rent", amount: 1100, due: 1 }, { id: uid(), name: "Phone", amount: 65, due: 15 }, { id: uid(), name: "Electric", amount: 120, due: 20 }, { id: uid(), name: "Car insurance", amount: 140, due: 9 } ];
  const m0 = new Date(TODAY.getFullYear(), TODAY.getMonth() - 4, 1);
  const hist = [[5100,1400,14500,9200],[4880,1290,13900,9050],[4650,1180,13200,8900],[4430,1060,12500,8750],[4200,950,11800,8600]];
  hist.forEach((row, i) => { const on = iso(new Date(m0.getFullYear(), m0.getMonth() + i, 1)); row.forEach((b, j) => s.snapshots.push({ id: uid(), debtId: s.debts[j].id, balance: b, on })); });
  return s;
}
function blankState(){ return { v: 3, example: false, strategy: "avalanche", extra: 0, updated: Date.now(), paid: {}, debts: [], pays: [], bills: [], snapshots: [], displayName: "", theme: "auto", onboarded: false }; }
function normalize(s){
  if (!s || typeof s !== "object" || !Array.isArray(s.debts)) return null;
  const out = blankState();
  out.example = !!s.example; out.displayName = String(s.displayName || ""); out.theme = ["light","dark"].includes(s.theme) ? s.theme : "auto"; out.onboarded = !!s.onboarded;
  out.strategy = s.strategy === "snowball" ? "snowball" : "avalanche"; out.extra = n(s.extra); out.updated = n(s.updated); out.paid = (s.paid && typeof s.paid === "object") ? s.paid : {};
  out.debts = s.debts.map(d => ({ id: String(d.id || uid()), name: String(d.name || "Debt"), balance: n(d.balance), start: d.start != null ? n(d.start) : n(d.balance), apr: n(d.apr), min: n(d.min), due: Math.round(n(d.due)) || 1 }));
  out.pays = (s.pays || []).map(p => ({ id: String(p.id || uid()), name: String(p.name || "Paycheck"), amount: n(p.amount), freq: ["once","weekly","biweekly","twice","monthly"].includes(p.freq) ? p.freq : "biweekly", date: parseISO(p.date) ? p.date : iso(TODAY), days: String(p.days || "1, 15"), spend: n(p.spend) }));
  out.bills = (s.bills || []).map(b => ({ id: String(b.id || uid()), name: String(b.name || "Bill"), amount: n(b.amount), due: Math.round(n(b.due)) || 1 }));
  out.snapshots = (s.snapshots || []).filter(x => x && parseISO(x.on)).map(x => ({ id: String(x.id || uid()), debtId: String(x.debtId || ""), balance: n(x.balance), on: x.on }));
  return out;
}
let state = null;
try { state = normalize(JSON.parse(localStorage.getItem(GUEST_KEY))); } catch (e) {}
if (!state) state = exampleState();

/* ---------- theme ---------- */
function applyTheme(){ const t = state.theme || "auto"; if (t === "auto") document.documentElement.removeAttribute("data-theme"); else document.documentElement.setAttribute("data-theme", t); try { localStorage.setItem("debtclear-theme", t); } catch (e) {} renderChart(); renderProgressChart(); }
try { const t = localStorage.getItem("debtclear-theme"); if (t && t !== "auto") document.documentElement.setAttribute("data-theme", t); } catch (e) {}
const themeBtn = $("#themeBtn");
if (themeBtn) themeBtn.onclick = () => { const dark = document.documentElement.getAttribute("data-theme") === "dark" || (!document.documentElement.getAttribute("data-theme") && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches); state.theme = dark ? "light" : "dark"; markDirty("profile"); save(); applyTheme(); };

/* ---------- store ---------- */
const dirty = { debts: new Set(), bills: new Set(), pays: new Set(), snapshots: new Set(), profile: false, deleted: [], full: false };
let syncTimer = null, syncing = false, syncAgain = false, online = false;
const TABLE = { debts: "debts", bills: "bills", pays: "paydays", snapshots: "balance_snapshots" };
function toRow(kind, it, i){
  const base = { id: it.id, user_id: DC.user.id };
  if (kind === "debts") return Object.assign(base, { name: it.name || "", sort_order: i, balance: n(it.balance), starting_balance: n(it.start), apr: n(it.apr), minimum: n(it.min), due_day: it.due || 1 });
  if (kind === "bills") return Object.assign(base, { name: it.name || "", sort_order: i, amount: n(it.amount), due_day: it.due || 1 });
  if (kind === "snapshots") return Object.assign(base, { debt_id: it.debtId || null, balance: n(it.balance), recorded_on: it.on });
  return Object.assign(base, { name: it.name || "", sort_order: i, amount: n(it.amount), frequency: it.freq, anchor_date: parseISO(it.date) ? it.date : null, days_of_month: String(it.days || "1, 15"), personal_spend: n(it.spend) });
}
function fromRows(rows){
  const s = blankState(); const p = rows.profile || {};
  s.strategy = p.strategy === "snowball" ? "snowball" : "avalanche"; s.extra = n(p.extra_monthly); s.displayName = p.display_name || ""; s.theme = ["light","dark"].includes(p.theme) ? p.theme : "auto"; s.onboarded = !!p.onboarded;
  s.debts = rows.debts.map(r => ({ id: r.id, name: r.name, balance: n(r.balance), start: r.starting_balance != null ? n(r.starting_balance) : n(r.balance), apr: n(r.apr), min: n(r.minimum), due: r.due_day || 1 }));
  s.bills = rows.bills.map(r => ({ id: r.id, name: r.name, amount: n(r.amount), due: r.due_day || 1 }));
  s.pays = rows.paydays.map(r => ({ id: r.id, name: r.name, amount: n(r.amount), freq: r.frequency, date: r.anchor_date || iso(TODAY), days: r.days_of_month || "1, 15", spend: n(r.personal_spend) }));
  s.snapshots = rows.snapshots.map(r => ({ id: r.id, debtId: r.debt_id || "", balance: n(r.balance), on: r.recorded_on }));
  rows.payments.forEach(x => { s.paid[x.item_key] = 1; }); s.updated = Date.now(); return s;
}
async function loadAccount(){
  const sb = DC.sb, u = DC.user.id;
  const q = await Promise.all([ sb.from("profiles").select("*").eq("id", u).maybeSingle(), sb.from("debts").select("*").eq("user_id", u).order("sort_order"), sb.from("bills").select("*").eq("user_id", u).order("sort_order"), sb.from("paydays").select("*").eq("user_id", u).order("sort_order"), sb.from("payments").select("item_key").eq("user_id", u), sb.from("balance_snapshots").select("*").eq("user_id", u).order("recorded_on") ]);
  for (const r of q) if (r.error) throw r.error;
  return { profile: q[0].data, debts: q[1].data || [], bills: q[2].data || [], paydays: q[3].data || [], payments: q[4].data || [], snapshots: q[5].data || [] };
}
async function saveProfile(){ const r = await DC.sb.from("profiles").upsert({ id: DC.user.id, strategy: state.strategy, extra_monthly: n(state.extra), display_name: state.displayName || null, theme: state.theme || "auto", onboarded: !!state.onboarded }); if (r.error) throw r.error; }
async function replaceAll(){
  const sb = DC.sb, u = DC.user.id;
  for (const t of ["balance_snapshots", "payments", "debts", "bills", "paydays"]){ const r = await sb.from(t).delete().eq("user_id", u); if (r.error) throw r.error; }
  const ins = async (t, rows) => { if (!rows.length) return; const r = await sb.from(t).insert(rows); if (r.error) throw r.error; };
  await ins("debts", state.debts.map((x, i) => toRow("debts", x, i))); await ins("bills", state.bills.map((x, i) => toRow("bills", x, i))); await ins("paydays", state.pays.map((x, i) => toRow("pays", x, i)));
  await ins("balance_snapshots", state.snapshots.filter(x => !x.debtId || state.debts.some(d => d.id === x.debtId)).map(x => toRow("snapshots", x)));
  await ins("payments", Object.keys(state.paid).map(k => ({ user_id: u, item_key: k }))); await saveProfile();
}
function setSync(kind, msg){ document.querySelectorAll(".sync").forEach(el => { el.className = "status sync " + kind; el.textContent = msg; }); }
function save(){ const cut = iso(addDays(TODAY, -60)); Object.keys(state.paid).forEach(k => { if (k.slice(-10) < cut) delete state.paid[k]; }); try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} if (online){ clearTimeout(syncTimer); syncTimer = setTimeout(flush, 700); } }
async function flush(){
  if (!online) return; if (syncing){ syncAgain = true; return; } syncing = true; setSync("saving", "Saving…");
  try { const sb = DC.sb;
    if (dirty.full){ dirty.full = false; ["debts","bills","pays","snapshots"].forEach(k => dirty[k].clear()); dirty.deleted = []; dirty.profile = false; await replaceAll(); }
    else {
      for (const del of dirty.deleted.splice(0)){ const r = await sb.from(TABLE[del.kind]).delete().eq("id", del.id); if (r.error) throw r.error; }
      for (const kind of ["debts", "bills", "pays", "snapshots"]){ const ids = [...dirty[kind]]; dirty[kind].clear(); if (!ids.length) continue;
        const rows = state[kind].map((x, i) => [x, i]).filter(([x]) => ids.includes(x.id)).map(([x, i]) => toRow(kind, x, i));
        if (rows.length){ const r = await sb.from(TABLE[kind]).upsert(rows); if (r.error) throw r.error; } }
      if (dirty.profile){ dirty.profile = false; await saveProfile(); } }
    setSync("account", "Saved to your account");
  } catch (e){ console.warn("sync failed", e); setSync("error", "Couldn't save to your account. Your changes are kept in this browser."); }
  syncing = false; if (syncAgain){ syncAgain = false; flush(); }
}
function markDirty(kind, id){ if (!online) return; if (kind === "profile") dirty.profile = true; else dirty[kind].add(id); }
function markDeleted(kind, id){ if (!online) return; dirty[kind].delete(id); dirty.deleted.push({ kind, id }); }
function markFull(){ if (online) dirty.full = true; }
async function setPaid(key, on){ if (!online) return; try { if (on) await DC.sb.from("payments").upsert({ user_id: DC.user.id, item_key: key }, { onConflict: "user_id,item_key" }); else await DC.sb.from("payments").delete().eq("user_id", DC.user.id).eq("item_key", key); } catch (e){ console.warn(e); } }
function touched(){ if (state.example) state.example = false; state.updated = Date.now(); save(); renderAll(); }
async function boot(){
  applyTheme();
  if (!DC.ready){ renderAll(); return; }
  const user = await DC.ready; const guard = document.body.dataset.requireAuth === "1";
  if (!user){ if (guard){ location.replace("signin.html?next=" + encodeURIComponent(location.pathname.split("/").pop())); return; } renderAll(); return; }
  KEY = CACHE_KEY; let cached = null; try { cached = normalize(JSON.parse(localStorage.getItem(CACHE_KEY))); } catch (e) {}
  const guest = state && !state.example ? state : null;
  state = cached || blankState(); renderAll(); setSync("saving", "Loading your plan…");
  try { const rows = await loadAccount(); const empty = !rows.debts.length && !rows.bills.length && !rows.paydays.length;
    if (empty && guest){ state = guest; state.onboarded = true; online = true; markFull(); save(); try { localStorage.removeItem(GUEST_KEY); } catch (e) {} applyTheme(); renderAll(); await flush(); toast("Your plan from this browser is now saved to your account."); }
    else { state = fromRows(rows); online = true; try { localStorage.setItem(CACHE_KEY, JSON.stringify(state)); } catch (e) {} applyTheme(); renderAll(); setSync("account", "Saved to your account"); }
  } catch (e){ console.warn(e); online = false; setSync("error", "Couldn't reach your account. Showing what's saved in this browser."); renderAll(); }
}
function toast(msg){ let t = $("#toast"); if (!t){ t = document.createElement("div"); t.id = "toast"; t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); } t.textContent = msg; t.style.display = "block"; clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = "none", 3800); }

/* ---------- dates ---------- */
function* monthsIn(from, to){ let y = from.getFullYear(), m = from.getMonth(); while (new Date(y, m, 1) <= to){ yield [y, m]; m++; if (m > 11){ m = 0; y++; } } }
function payDates(p, from, to){
  const out = []; if (!(n(p.amount) > 0)) return out;
  if (p.freq === "twice"){ const days = [...new Set(String(p.days).split(/[^0-9]+/).map(Number).filter(x => x >= 1 && x <= 31))]; for (const [y, m] of monthsIn(from, to)) for (const dd of days){ const d = onDay(y, m, dd); if (d >= from && d <= to) out.push(d); } return out.sort((a, b) => a - b); }
  const anchor = parseISO(p.date); if (!anchor) return out;
  if (p.freq === "once"){ if (anchor >= from && anchor <= to) out.push(anchor); return out; }
  if (p.freq === "monthly"){ for (const [y, m] of monthsIn(from, to)){ const d = onDay(y, m, anchor.getDate()); if (d >= from && d <= to) out.push(d); } return out; }
  const step = p.freq === "weekly" ? 7 : 14; const diff = Math.round((from - anchor) / 864e5); const k = diff > 0 ? Math.ceil(diff / step) : 0;
  for (let d = addDays(anchor, k * step); d <= to; d = addDays(d, step)) if (d >= from) out.push(d); return out;
}
function dueDates(day, from, to){ const out = []; for (const [y, m] of monthsIn(from, to)){ const d = onDay(y, m, day); if (d >= from && d <= to) out.push(d); } return out; }
function perMonth(p){ if (p.freq === "weekly") return 52 / 12; if (p.freq === "biweekly") return 26 / 12; if (p.freq === "twice") return new Set(String(p.days).split(/[^0-9]+/).map(Number).filter(x => x >= 1 && x <= 31)).size; if (p.freq === "monthly") return 1; return 0; }
function leftoverMonthly(){ const income = state.pays.reduce((s, p) => s + n(p.amount) * perMonth(p), 0), spend = state.pays.reduce((s, p) => s + n(p.spend) * perMonth(p), 0); const bills = state.bills.reduce((s, b) => s + n(b.amount), 0), mins = state.debts.filter(d => n(d.balance) > 0).reduce((s, d) => s + n(d.min), 0); return income - spend - bills - mins; }

/* ---------- simulation ---------- */
function simulate(strategy, extraOverride){
  const ds = state.debts.filter(d => n(d.balance) > 0).map(d => ({ id: d.id, name: d.name, bal: n(d.balance), apr: Math.max(0, n(d.apr)), min: Math.max(0, n(d.min)), paid: 0, int: 0 }));
  if (!ds.length) return null;
  const order = [...ds].sort(strategy === "avalanche" ? (a, b) => b.apr - a.apr || a.bal - b.bal : (a, b) => a.bal - b.bal || b.apr - a.apr);
  const extra = Math.max(0, extraOverride != null ? extraOverride : n(state.extra)); const budget = ds.reduce((s, d) => s + d.min, 0) + extra;
  const start = new Date(TODAY.getFullYear(), TODAY.getMonth() + 1, 1); const startTotal = ds.reduce((s, d) => s + d.bal, 0);
  const months = [], payoff = {}; let interest = 0, m = 0;
  while (ds.some(d => d.bal > 0.005) && m < 600){
    const row = { date: new Date(start.getFullYear(), start.getMonth() + m, 1), pay: {}, bal: {}, interest: 0 };
    for (const d of ds) if (d.bal > 0){ const i = d.bal * d.apr / 1200; d.bal += i; d.int += i; row.interest += i; }
    let pool = budget;
    for (const d of ds) if (d.bal > 0){ const p = Math.min(d.min, d.bal, pool); d.bal -= p; pool -= p; row.pay[d.id] = p; }
    for (const d of order){ if (pool <= 0.005) break; if (d.bal > 0.005){ const p = Math.min(d.bal, pool); d.bal -= p; pool -= p; row.pay[d.id] = (row.pay[d.id] || 0) + p; } }
    for (const d of ds){ if (d.bal < 0.005) d.bal = 0; row.bal[d.id] = d.bal; if (d.bal === 0 && payoff[d.id] == null) payoff[d.id] = m; }
    row.total = ds.reduce((s, d) => s + d.bal, 0); interest += row.interest; months.push(row); m++;
    if (m === 24 && row.total >= startTotal) break;
  }
  const perDebt = {}; ds.forEach(d => perDebt[d.id] = { interest: d.int });
  return { months, interest, payoff, order: order.map(d => d.id), budget, extra, stuck: ds.some(d => d.bal > 0.005), startTotal, perDebt };
}
function spanText(k){ const y = Math.floor(k / 12), mo = k % 12; return ((y ? y + " yr " : "") + (mo || !y ? mo + " mo" : "")).trim(); }
let sims = { avalanche: null, snowball: null };
function runSims(){ sims.avalanche = simulate("avalanche"); sims.snowball = simulate("snowball"); }
function progressNumbers(){
  const active = state.debts.filter(d => n(d.balance) > 0 || n(d.start) > 0);
  const startTotal = active.reduce((s, d) => s + Math.max(n(d.start), n(d.balance)), 0), now = active.reduce((s, d) => s + n(d.balance), 0);
  const paid = Math.max(0, startTotal - now); const pct = startTotal > 0 ? paid / startTotal : 0;
  return { startTotal, now, paid, pct, paidOffCount: state.debts.filter(d => n(d.start) > 0 && n(d.balance) <= 0).length };
}

/* ---------- common / mast ---------- */
function renderCommon(){
  const b = $("#exampleBanner"); if (b) b.hidden = !state.example;
  document.querySelectorAll("[data-strat]").forEach(x => x.setAttribute("aria-pressed", String(x.dataset.strat === state.strategy)));
  const hi = $("#greet"); if (hi){ const nm = state.displayName || (DC.user && DC.user.user_metadata && DC.user.user_metadata.full_name) || ""; const h = T0.getHours(); hi.textContent = (h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening") + (nm ? ", " + nm.split(" ")[0] : "") + "."; }
}
document.querySelectorAll("[data-strat]").forEach(b => b.addEventListener("click", () => { state.strategy = b.dataset.strat; markDirty("profile"); state.updated = Date.now(); save(); renderAll(); }));
const clearEx = $("#clearExample"); if (clearEx) clearEx.onclick = () => { state = blankState(); markFull(); save(); renderAll(); toast("Blank plan ready. Start with your debts."); };
function renderMast(){
  if (!$("#mDate")) return;
  const sel = sims[state.strategy], other = sims[state.strategy === "avalanche" ? "snowball" : "avalanche"]; const pr = progressNumbers();
  const set = (id, v) => { const el = $(id); if (el) el.innerHTML = v; };
  const ring = $("#ringBar"); if (ring){ const C = 2 * Math.PI * 62; ring.style.strokeDasharray = C; ring.style.strokeDashoffset = C * (1 - Math.min(1, pr.pct)); }
  set("#ringPct", Math.round(pr.pct * 100) + "%");
  set("#mDebt", pr.now > 0 || pr.startTotal > 0 ? money(pr.now) : "—"); set("#mDebtSub", pr.startTotal > 0 ? money(pr.paid) + " paid off so far" : "Add your debts");
  if (!sel){ set("#mDate", "—"); set("#mDateSub", "Add a debt to see it"); set("#mInt", "—"); set("#mIntSub", "&nbsp;"); return; }
  if (sel.stuck){ set("#mDate", "Not yet"); set("#mDateSub", "Payments don't cover the interest"); set("#mInt", "—"); set("#mIntSub", "Add an extra payment"); return; }
  const last = sel.months[sel.months.length - 1].date; set("#mDate", mLabel(last)); set("#mDateSub", spanText(sel.months.length) + " with " + (state.strategy === "avalanche" ? "Avalanche" : "Snowball"));
  set("#mInt", money(sel.interest));
  if (other && !other.stuck){ const diff = other.interest - sel.interest; const on = state.strategy === "avalanche" ? "Snowball" : "Avalanche"; set("#mIntSub", Math.abs(diff) < 1 ? "Same as " + on : (diff >= 0 ? money(diff) + " less than " : money(-diff) + " more than ") + on); } else set("#mIntSub", "total interest");
}

/* ---------- editable rows ---------- */
function field(label, attrs){ return '<label>' + label + '<input ' + attrs + '></label>'; }
function renderInputs(){
  const dr = $("#debtRows");
  if (dr) dr.innerHTML = state.debts.length ? state.debts.map(d => '<div class="row debt" data-kind="debts" data-id="' + esc(d.id) + '">' +
      field("Name", 'data-f="name" type="text" value="' + esc(d.name) + '"') + field("Balance ($)", 'data-f="balance" type="number" min="0" step="any" inputmode="decimal" value="' + esc(d.balance) + '"') +
      field("APR %", 'data-f="apr" type="number" min="0" step="any" inputmode="decimal" value="' + esc(d.apr) + '"') + field("Minimum ($)", 'data-f="min" type="number" min="0" step="any" inputmode="decimal" value="' + esc(d.min) + '"') +
      field("Due day", 'data-f="due" type="number" min="1" max="31" inputmode="numeric" value="' + esc(d.due) + '"') +
      '<button class="x" type="button" data-del aria-label="Remove ' + esc(d.name) + '">×</button><div class="meta" data-meta></div></div>').join("") : '<div class="empty">No debts yet. Add your first one to see a payoff date.</div>';
  const pr = $("#payRows");
  if (pr) pr.innerHTML = state.pays.length ? state.pays.map(p => { const when = p.freq === "twice" ? field("Pay days of month", 'data-f="days" type="text" value="' + esc(p.days) + '" placeholder="1, 15"') : field(p.freq === "monthly" ? "Next pay date" : p.freq === "once" ? "Pay date" : "A recent or next pay date", 'data-f="date" type="date" value="' + esc(p.date) + '"');
    return '<div class="row pay" data-kind="pays" data-id="' + esc(p.id) + '">' + field("Income source", 'data-f="name" type="text" value="' + esc(p.name) + '"') + field("Take-home ($)", 'data-f="amount" type="number" min="0" step="any" inputmode="decimal" value="' + esc(p.amount) + '"') +
      '<label>Repeats<select data-f="freq">' + [["once","Does not repeat"],["weekly","Weekly"],["biweekly","Every two weeks"],["twice","Twice a month"],["monthly","Monthly"]].map(([v, t]) => '<option value="' + v + '"' + (p.freq === v ? " selected" : "") + '>' + t + '</option>').join("") + '</select></label>' + when +
      field("For you ($)", 'data-f="spend" type="number" min="0" step="any" inputmode="decimal" value="' + esc(p.spend) + '" title="Personal spending you keep from each check"') + '<button class="x" type="button" data-del aria-label="Remove ' + esc(p.name) + '">×</button><div class="meta" data-meta></div></div>'; }).join("") : '<div class="empty">No paydays yet. Add one to get a paycheck-by-paycheck plan.</div>';
  const br = $("#billRows");
  if (br) br.innerHTML = state.bills.length ? state.bills.map(b => '<div class="row bill" data-kind="bills" data-id="' + esc(b.id) + '">' + field("Bill", 'data-f="name" type="text" value="' + esc(b.name) + '"') + field("Amount ($)", 'data-f="amount" type="number" min="0" step="any" inputmode="decimal" value="' + esc(b.amount) + '"') + field("Due day", 'data-f="due" type="number" min="1" max="31" inputmode="numeric" value="' + esc(b.due) + '"') + '<button class="x" type="button" data-del aria-label="Remove ' + esc(b.name) + '">×</button></div>').join("") : '<div class="empty">No bills yet.</div>';
  document.querySelectorAll(".row").forEach(r => r.querySelectorAll("[data-f]").forEach(el => { el.id = r.dataset.kind + "-" + r.dataset.id + "-" + el.dataset.f; }));
  const ex = $("#extra"); if (ex && document.activeElement !== ex) ex.value = state.extra || "";
}
function renderMeta(){
  const sel = sims[state.strategy];
  document.querySelectorAll('.row.debt').forEach(r => { const d = state.debts.find(x => x.id === r.dataset.id); const meta = r.querySelector("[data-meta]"); if (!d || !meta) return;
    if (!(n(d.balance) > 0)){ meta.innerHTML = n(d.start) > 0 ? '<span class="pill">Paid off 🎉</span>' : ""; return; } const parts = [];
    if (sel){ const idx = sel.order.indexOf(d.id); parts.push('<span class="pill' + (idx === 0 ? "" : " sun") + '">' + (idx === 0 ? "Target now" : "#" + (idx + 1) + " in line") + '</span>'); if (sel.payoff[d.id] != null) parts.push("Paid off " + mLabel(sel.months[sel.payoff[d.id]].date)); if (sel.perDebt[d.id]) parts.push(money(sel.perDebt[d.id].interest) + " interest to go"); }
    const mi = n(d.balance) * n(d.apr) / 1200; if (n(d.min) <= mi && n(d.min) > 0) parts.push('<span class="pill warn">Minimum is below the ' + money2(mi) + ' monthly interest</span>');
    meta.innerHTML = parts.join(" · "); });
  document.querySelectorAll('.row.pay').forEach(r => { const p = state.pays.find(x => x.id === r.dataset.id); const meta = r.querySelector("[data-meta]"); if (!p || !meta) return; const next = payDates(p, TODAY, addDays(TODAY, 400))[0];
    meta.innerHTML = next ? "Next: " + dLabel(next) + " · " + money(n(p.amount) - n(p.spend)) + " left for bills, debt & savings" : (n(p.amount) > 0 ? '<span class="pill warn">No upcoming date</span>' : ""); });
  const lh = $("#leftoverHint"), ul = $("#useLeftover");
  if (lh){ const lo = leftoverMonthly(); if (state.pays.length){ lh.innerHTML = lo >= 0 ? "Your paychecks leave about <strong class='num'>" + money(lo) + "</strong> a month after spending, bills and minimums." : "<span class='pill warn'>Short about " + money(-lo) + " a month</span> after spending, bills and minimums."; if (ul) ul.hidden = !(lo > 0) || Math.abs(lo - n(state.extra)) < 10; } else { lh.innerHTML = 'Add your <a href="paychecks.html">paydays and bills</a> and this will show how much you have left each month.'; if (ul) ul.hidden = true; } }
}
document.addEventListener("input", e => {
  const el = e.target; const row = el.closest && el.closest(".row"); if (!row || !el.dataset.f) return;
  const item = state[row.dataset.kind].find(x => x.id === row.dataset.id); if (!item) return;
  const f = el.dataset.f; item[f] = (el.type === "number") ? (f === "due" ? Math.min(31, Math.max(1, Math.round(n(el.value)) || 1)) : n(el.value)) : el.value;
  if (f === "balance" && row.dataset.kind === "debts" && n(el.value) > n(item.start)) item.start = n(el.value);
  markDirty(row.dataset.kind, item.id);
  if (f === "freq"){ if (item.freq !== "twice" && !parseISO(item.date)) item.date = iso(TODAY); touched(); return; }
  if (state.example) state.example = false; state.updated = Date.now(); save(); renderLight();
});
document.addEventListener("click", e => { const del = e.target.closest && e.target.closest("[data-del]"); if (!del) return; const row = del.closest(".row"); state[row.dataset.kind] = state[row.dataset.kind].filter(x => x.id !== row.dataset.id); markDeleted(row.dataset.kind, row.dataset.id); touched(); });
function focusLast(sel){ const rows = document.querySelectorAll(sel + " .row"); const r = rows[rows.length - 1]; if (r){ const i = r.querySelector("input"); i.focus(); i.select(); } }
const bind = (id, fn) => { const el = $(id); if (el) el.onclick = fn; };
bind("#addDebt", () => { const d = { id: uid(), name: "New debt", balance: 0, start: 0, apr: 0, min: 0, due: 1 }; state.debts.push(d); markDirty("debts", d.id); touched(); focusLast("#debtRows"); });
bind("#addBill", () => { const b = { id: uid(), name: "New bill", amount: 0, due: 1 }; state.bills.push(b); markDirty("bills", b.id); touched(); focusLast("#billRows"); });
bind("#addPay", () => { const p = { id: uid(), name: "Paycheck", amount: 0, freq: "biweekly", date: iso(TODAY), days: "1, 15", spend: 0 }; state.pays.push(p); markDirty("pays", p.id); touched(); focusLast("#payRows"); });
const exIn = $("#extra"); if (exIn) exIn.addEventListener("input", e => { state.extra = Math.max(0, n(e.target.value)); markDirty("profile"); if (state.example) state.example = false; state.updated = Date.now(); save(); renderLight(); });
bind("#useLeftover", () => { state.extra = Math.max(0, Math.floor(leftoverMonthly() / 10) * 10); markDirty("profile"); touched(); });

/* ---------- what-if ---------- */
const wi = $("#whatIf");
function renderWhatIf(){ if (!wi) return; const sel = sims[state.strategy]; const box = $("#whatIfOut"); if (!sel || sel.stuck){ box.innerHTML = '<span class="hint">Add a debt to try this.</span>'; return; }
  const add = n(wi.value); const alt = simulate(state.strategy, n(state.extra) + add); $("#whatIfAmt").textContent = money(add);
  if (!alt || alt.stuck){ box.innerHTML = ""; return; } const mSaved = sel.months.length - alt.months.length, iSaved = sel.interest - alt.interest;
  box.innerHTML = add > 0 ? '<span>Debt-free <b>' + mLabel(alt.months[alt.months.length - 1].date) + '</b></span><span class="gain">' + (mSaved > 0 ? spanText(mSaved) + " sooner" : "same date") + ' · saves ' + money(Math.max(0, iSaved)) + ' in interest</span>' : '<span class="hint">Drag the slider to see what extra money would do.</span>'; }
if (wi){ wi.addEventListener("input", renderWhatIf); bind("#whatIfApply", () => { state.extra = n(state.extra) + n(wi.value); wi.value = 0; markDirty("profile"); touched(); toast("Extra payment updated to " + money(state.extra) + "/mo."); }); }

/* ---------- chart ---------- */
let chartGeom = null;
function css(v){ return getComputedStyle(document.documentElement).getPropertyValue(v).trim(); }
function niceMax(v){ if (v <= 0) return 1000; const p = Math.pow(10, Math.floor(Math.log10(v))); const f = v / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; }
function setupCanvas(cv){ const box = cv.parentElement; const dpr = window.devicePixelRatio || 1; const W = box.clientWidth, H = box.clientHeight; cv.width = W * dpr; cv.height = H * dpr; const ctx = cv.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H); ctx.font = "12px " + css("--body"); return { ctx, W, H }; }
function grid(ctx, W, H, L, R, Tp, B, maxV){ const ph = H - Tp - B; const Y = v => Tp + ph - (v / maxV) * ph; ctx.strokeStyle = css("--line"); ctx.lineWidth = 1; ctx.fillStyle = css("--muted"); ctx.textAlign = "right"; ctx.textBaseline = "middle";
  for (let k = 0; k <= 4; k++){ const v = maxV * k / 4, y = Math.round(Y(v)) + .5; ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(W - R, y); ctx.stroke(); ctx.fillText(v >= 1000 ? "$" + (v / 1000).toFixed(v % 1000 ? 1 : 0) + "k" : "$" + v, L - 8, y); } return Y; }
function renderChart(hover){
  const cv = $("#chart"); if (!cv) return; const { ctx, W, H } = setupCanvas(cv);
  const muted = css("--muted"), A = css("--accent"), S = css("--sun"), ink = css("--ink"); const a = sims.avalanche, s = sims.snowball;
  if (!a){ ctx.fillStyle = muted; ctx.textAlign = "center"; ctx.fillText("Your balance chart appears once you add a debt.", W / 2, H / 2); chartGeom = null; return; }
  const ser = [a, s].map(x => x ? [x.startTotal].concat(x.months.map(r => r.total)) : []); const len = Math.max(ser[0].length, ser[1].length); const maxV = niceMax(Math.max(...ser[0], ...ser[1]));
  const L = 58, R = 14, Tp = 12, B = 26, pw = W - L - R, ph = H - Tp - B; const X = i => L + (len > 1 ? i / (len - 1) : 0) * pw; const Y = grid(ctx, W, H, L, R, Tp, B, maxV);
  ctx.textAlign = "center"; ctx.textBaseline = "top"; const start = new Date(TODAY.getFullYear(), TODAY.getMonth(), 1); const stepM = len > 60 ? 24 : len > 30 ? 12 : len > 12 ? 6 : 3;
  for (let i = 0; i < len; i += stepM){ const d = new Date(start.getFullYear(), start.getMonth() + i, 1); ctx.fillText(i === 0 ? "Now" : mLabel(d), X(i), H - B + 7); }
  const chosen = state.strategy === "avalanche" ? 0 : 1;
  [1 - chosen, chosen].forEach(k => { const pts = ser[k]; if (!pts.length) return; const col = k === 0 ? A : S;
    if (k === chosen){ const g = ctx.createLinearGradient(0, Tp, 0, Tp + ph); g.addColorStop(0, col + "40"); g.addColorStop(1, col + "00"); ctx.beginPath(); ctx.moveTo(X(0), Y(0)); pts.forEach((v, i) => ctx.lineTo(X(i), Y(v))); ctx.lineTo(X(pts.length - 1), Y(0)); ctx.closePath(); ctx.fillStyle = g; ctx.fill(); }
    ctx.beginPath(); pts.forEach((v, i) => i ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v))); ctx.strokeStyle = col; ctx.lineWidth = k === chosen ? 2.5 : 1.6; ctx.setLineDash(k === chosen ? [] : [5, 4]); ctx.stroke(); ctx.setLineDash([]);
    const li = pts.length - 1; ctx.beginPath(); ctx.arc(X(li), Y(pts[li]), 4, 0, 7); ctx.fillStyle = col; ctx.fill(); });
  if (hover != null && hover < len){ const x = X(hover); ctx.strokeStyle = ink; ctx.globalAlpha = .35; ctx.beginPath(); ctx.moveTo(x, Tp); ctx.lineTo(x, Tp + ph); ctx.stroke(); ctx.globalAlpha = 1; [0, 1].forEach(k => { const v = ser[k][Math.min(hover, ser[k].length - 1)]; if (v == null) return; ctx.beginPath(); ctx.arc(x, Y(v), 4, 0, 7); ctx.fillStyle = k ? S : A; ctx.fill(); }); }
  chartGeom = { X, len, L, pw, ser, start };
}
(function(){ const cv = $("#chart"), tip = $("#tip"); if (!cv) return;
  function move(ev){ if (!chartGeom) return; const r = cv.getBoundingClientRect(); const g = chartGeom; let i = Math.round(((ev.clientX - r.left - g.L) / g.pw) * (g.len - 1)); i = Math.max(0, Math.min(g.len - 1, i)); renderChart(i); const d = new Date(g.start.getFullYear(), g.start.getMonth() + i, 1);
    const va = g.ser[0][Math.min(i, g.ser[0].length - 1)], vs = g.ser[1][Math.min(i, g.ser[1].length - 1)]; if (tip){ tip.innerHTML = "<strong>" + (i === 0 ? "Now" : mLabel(d)) + "</strong><br>Avalanche <span class='num'>" + money(va) + "</span><br>Snowball <span class='num'>" + money(vs) + "</span>"; tip.style.display = "block"; tip.style.left = Math.min(Math.max(g.X(i), 70), r.width - 70) + "px"; tip.style.top = "64px"; } }
  cv.addEventListener("pointermove", move); cv.addEventListener("pointerdown", move); cv.addEventListener("pointerleave", () => { if (tip) tip.style.display = "none"; renderChart(); }); })();
let rt; window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(() => { renderChart(); renderProgressChart(); }, 100); });
if (window.matchMedia) window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => { renderChart(); renderProgressChart(); });

/* ---------- progress (snapshots) ---------- */
function snapshotSeries(){ const byDate = {}; state.snapshots.forEach(s => { if (s.debtId && !state.debts.some(d => d.id === s.debtId)) return; (byDate[s.on] = byDate[s.on] || {})[s.debtId || "_"] = n(s.balance); });
  const dates = Object.keys(byDate).sort(); const last = {}; return dates.map(on => { Object.assign(last, byDate[on]); return { on, total: Object.values(last).reduce((a, b) => a + b, 0) }; }); }
function renderProgressChart(){
  const cv = $("#progressChart"); if (!cv) return; const { ctx, W, H } = setupCanvas(cv); const muted = css("--muted"), A = css("--accent"), S = css("--sun");
  const hist = snapshotSeries(); const sel = sims[state.strategy];
  if (hist.length < 2 && !sel){ ctx.fillStyle = muted; ctx.textAlign = "center"; ctx.fillText("Log your balances a few times and your real progress shows up here.", W / 2, H / 2); return; }
  const first = hist.length ? parseISO(hist[0].on) : new Date(TODAY.getFullYear(), TODAY.getMonth(), 1); const plan = sel ? [{ on: iso(TODAY), total: sel.startTotal }].concat(sel.months.map(r => ({ on: iso(r.date), total: r.total }))) : [];
  const lastD = plan.length ? parseISO(plan[plan.length - 1].on) : parseISO(hist[hist.length - 1].on); const span = Math.max(30, (lastD - first) / 864e5);
  const maxV = niceMax(Math.max(...hist.map(h => h.total), ...plan.map(p => p.total), 1)); const L = 58, R = 14, Tp = 12, B = 26, pw = W - L - R;
  const X = d => L + ((parseISO(d) - first) / 864e5) / span * pw; const Y = grid(ctx, W, H, L, R, Tp, B, maxV);
  ctx.textAlign = "center"; ctx.textBaseline = "top"; const months = Math.round(span / 30); const stepM = months > 60 ? 24 : months > 30 ? 12 : months > 12 ? 6 : months > 6 ? 3 : 1;
  for (let i = 0; i <= months; i += stepM){ const d = new Date(first.getFullYear(), first.getMonth() + i, 1); if (d > addDays(lastD, 15)) break; ctx.fillText(mLabel(d), X(iso(d)), H - B + 7); }
  if (plan.length){ ctx.beginPath(); plan.forEach((p, i) => i ? ctx.lineTo(X(p.on), Y(p.total)) : ctx.moveTo(X(p.on), Y(p.total))); ctx.strokeStyle = S; ctx.lineWidth = 1.6; ctx.setLineDash([5, 4]); ctx.stroke(); ctx.setLineDash([]); }
  if (hist.length){ const g = ctx.createLinearGradient(0, Tp, 0, H - B); g.addColorStop(0, A + "40"); g.addColorStop(1, A + "00"); ctx.beginPath(); ctx.moveTo(X(hist[0].on), Y(0)); hist.forEach(h => ctx.lineTo(X(h.on), Y(h.total))); ctx.lineTo(X(hist[hist.length - 1].on), Y(0)); ctx.closePath(); ctx.fillStyle = g; ctx.fill();
    ctx.beginPath(); hist.forEach((h, i) => i ? ctx.lineTo(X(h.on), Y(h.total)) : ctx.moveTo(X(h.on), Y(h.total))); ctx.strokeStyle = A; ctx.lineWidth = 2.5; ctx.stroke(); hist.forEach(h => { ctx.beginPath(); ctx.arc(X(h.on), Y(h.total), 3.5, 0, 7); ctx.fillStyle = A; ctx.fill(); }); }
}
function renderProgress(){
  const box = $("#snapRows"); if (!box) return; const active = state.debts.filter(d => n(d.balance) > 0 || n(d.start) > 0);
  const lastFor = id => { const xs = state.snapshots.filter(s => s.debtId === id).sort((a, b) => a.on < b.on ? 1 : -1); return xs[0]; };
  box.innerHTML = active.length ? active.map(d => { const last = lastFor(d.id); return '<div class="snap-row" data-id="' + esc(d.id) + '"><div><strong>' + esc(d.name) + '</strong><div class="was">' + (last ? "Last logged " + money(last.balance) + " on " + short(parseISO(last.on)) : "Never logged") + '</div></div><input type="number" min="0" step="any" inputmode="decimal" value="' + esc(d.balance) + '" aria-label="Current balance for ' + esc(d.name) + '"><span class="delta" data-delta></span></div>'; }).join("") : '<div class="empty">Add debts on the Planner page first.</div>';
  box.querySelectorAll("input").forEach(i => i.addEventListener("input", () => { const row = i.closest(".snap-row"); const d = state.debts.find(x => x.id === row.dataset.id); const diff = n(i.value) - n(d.balance); const el = row.querySelector("[data-delta]"); el.textContent = diff === 0 ? "" : (diff < 0 ? "−" : "+") + money(Math.abs(diff)); el.className = "delta " + (diff < 0 ? "down" : diff > 0 ? "up" : ""); }));
  const hist = snapshotSeries(); const tb = $("#snapTable");
  if (tb) tb.innerHTML = hist.length ? '<thead><tr><th>Date</th><th>Total owed</th><th>Change</th></tr></thead><tbody>' + hist.slice().reverse().map((h, i, arr) => { const prev = arr[i + 1]; const ch = prev ? h.total - prev.total : 0; return '<tr><td>' + short(parseISO(h.on)) + ', ' + parseISO(h.on).getFullYear() + '</td><td>' + money(h.total) + '</td><td class="' + (ch < 0 ? "off" : "") + '">' + (prev ? (ch <= 0 ? "−" : "+") + money(Math.abs(ch)) : "—") + '</td></tr>'; }).join("") + '</tbody>' : '<tbody><tr><td style="font-family:var(--body);color:var(--muted);text-align:center">No history yet. Log your balances above.</td></tr></tbody>';
  renderProgressChart(); renderMilestones();
}
bind("#logBalances", () => {
  const rows = document.querySelectorAll("#snapRows .snap-row"); if (!rows.length) return; const on = iso(TODAY); let changed = 0;
  rows.forEach(r => { const d = state.debts.find(x => x.id === r.dataset.id); const v = Math.max(0, n(r.querySelector("input").value)); if (v !== n(d.balance)){ d.balance = v; markDirty("debts", d.id); changed++; }
    const ex = state.snapshots.find(s => s.debtId === d.id && s.on === on); if (ex){ ex.balance = v; markDirty("snapshots", ex.id); } else { const s = { id: uid(), debtId: d.id, balance: v, on }; state.snapshots.push(s); markDirty("snapshots", s.id); } });
  touched(); toast(changed ? "Balances logged. " + changed + " updated." : "Balances logged for today."); });
function renderMilestones(){
  const box = $("#milestones"); if (!box) return; const pr = progressNumbers(); const ticks = Object.keys(state.paid).length; const sel = sims[state.strategy];
  const ms = [
    { t: "Plan made", s: "Debts entered", won: state.debts.length > 0 },
    { t: "First payment", s: "Ticked off a payment", won: ticks >= 1 },
    { t: "Logged progress", s: "Balances recorded", won: state.snapshots.length > 0 },
    { t: "10% down", s: money(pr.startTotal * .1) + " paid", won: pr.pct >= .1 },
    { t: "First debt gone", s: "One account at $0", won: pr.paidOffCount >= 1 },
    { t: "25% down", s: money(pr.startTotal * .25) + " paid", won: pr.pct >= .25 },
    { t: "Halfway", s: money(pr.startTotal * .5) + " paid", won: pr.pct >= .5 },
    { t: "75% down", s: money(pr.startTotal * .75) + " paid", won: pr.pct >= .75 },
    { t: "Debt-free", s: sel && !sel.stuck ? "Planned " + mLabel(sel.months[sel.months.length - 1].date) : "The big one", won: pr.startTotal > 0 && pr.now <= 0 } ];
  box.innerHTML = ms.map(m => '<div class="mile' + (m.won ? " won" : "") + '"><span class="ic">' + (m.won ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="9"/></svg>') + '</span><b>' + m.t + '</b><small>' + m.s + '</small></div>').join("");
  const c = $("#mileCount"); if (c) c.textContent = ms.filter(m => m.won).length + " of " + ms.length;
}

/* ---------- paycheck plan ---------- */
let checkRows = [];
function buildChecks(){
  const horizon = addDays(TODAY, 120); const raw = []; state.pays.forEach(p => payDates(p, TODAY, horizon).forEach(d => raw.push({ d, p }))); raw.sort((a, b) => a.d - b.d);
  const groups = []; raw.forEach(x => { const last = groups[groups.length - 1]; if (last && +last.d === +x.d) last.srcs.push(x.p); else groups.push({ d: x.d, srcs: [x.p] }); });
  const checks = groups.slice(0, 6); if (!checks.length) return { checks: [], before: [] };
  const end = groups[6] ? addDays(groups[6].d, -1) : addDays(checks[checks.length - 1].d, 30); const items = [];
  state.bills.forEach(b => { if (n(b.amount) > 0) dueDates(b.due, TODAY, end).forEach(d => items.push({ key: "b:" + b.id + ":" + iso(d), name: b.name, amt: n(b.amount), d, type: "out" })); });
  state.debts.forEach(dt => { if (n(dt.balance) > 0 && n(dt.min) > 0) dueDates(dt.due, TODAY, end).forEach(d => items.push({ key: "d:" + dt.id + ":" + iso(d), name: dt.name + " minimum", amt: Math.min(n(dt.min), n(dt.balance)), d, type: "debt" })); });
  items.sort((a, b) => a.d - b.d); const before = items.filter(it => it.d < checks[0].d);
  checks.forEach((c, i) => { const until = checks[i + 1] ? checks[i + 1].d : addDays(end, 1); c.items = items.filter(it => it.d >= c.d && it.d < until); c.gross = c.srcs.reduce((s, p) => s + n(p.amount), 0); c.spend = c.srcs.reduce((s, p) => s + n(p.spend), 0); c.cash = c.gross - c.spend; c.dues = c.items.reduce((s, it) => s + it.amt, 0); c.reserve = 0; c.covered = 0; });
  for (let i = checks.length - 1; i > 0; i--){ const need = checks[i].dues + checks[i].reserve - checks[i].cash; if (need > 0){ checks[i - 1].reserve += need; checks[i].covered = need; } }
  const sel = sims[state.strategy]; const target = sel ? state.debts.find(d => d.id === sel.order[0]) : null; const used = {};
  checks.forEach(c => { const free = c.cash + c.covered - c.dues - c.reserve; c.short = Math.max(0, -free); const mk = c.d.getFullYear() + "-" + c.d.getMonth(); const left = Math.max(0, n(state.extra) - (used[mk] || 0)); c.extra = target ? Math.min(Math.max(0, free), left) : 0; used[mk] = (used[mk] || 0) + c.extra; c.target = target; c.left = Math.max(0, free) - c.extra; });
  return { checks, before, items };
}
function liItem(it){ const done = !!state.paid[it.key]; return '<li class="' + (done ? "done" : "") + '"><input type="checkbox" data-paid="' + esc(it.key) + '" id="paid-' + esc(it.key).replace(/[^a-z0-9-]/gi, "_") + '"' + (done ? " checked" : "") + ' aria-label="Mark ' + esc(it.name) + ' paid"><span class="nm">' + esc(it.name) + '<small>due ' + short(it.d) + '</small></span><span class="amt">' + money2(it.amt) + '</span></li>'; }
function renderChecks(){
  const box = $("#checks"); if (!box) return;
  if (!state.pays.length){ box.innerHTML = '<div class="empty">Add a payday above and this turns into a plan for each paycheck.</div>'; checkRows = []; return; }
  const { checks, before } = buildChecks(); checkRows = checks; if (!checks.length){ box.innerHTML = '<div class="empty">No upcoming paydays found. Check the pay dates above.</div>'; return; }
  let html = ""; if (before.length) html += '<div class="prepay"><strong>Due before your next payday (' + short(checks[0].d) + ')</strong><ul class="lines" style="padding:4px 0 0">' + before.map(liItem).join("") + '</ul><span class="hint">Pay these from money you already have.</span></div>';
  html += checks.map(c => { const lines = ['<li><span class="spacer"></span><span class="nm">For you (personal spending)</span><span class="amt">' + money2(c.spend) + '</span></li>']; c.items.forEach(it => lines.push(liItem(it)));
    if (!c.items.length) lines.push('<li><span class="spacer"></span><span class="nm" style="color:var(--muted)">No bills or minimums due before the next check</span><span class="amt"></span></li>');
    if (c.covered > 0) lines.push('<li class="reserve"><span class="spacer"></span><span class="nm">Set aside from your last check</span><span class="amt">+' + money2(c.covered) + '</span></li>');
    if (c.reserve > 0) lines.push('<li class="reserve"><span class="spacer"></span><span class="nm">Set aside for bills due after next payday</span><span class="amt">' + money2(c.reserve) + '</span></li>');
    if (c.extra > 0 && c.target) lines.push('<li class="extra"><span class="spacer"></span><span class="nm">Extra to ' + esc(c.target.name) + ' (target)</span><span class="amt">' + money2(c.extra) + '</span></li>');
    lines.push('<li class="total"><span class="spacer"></span><span class="nm">' + (c.short > 0 ? "Short" : "Left over for savings") + '</span><span class="amt" style="color:' + (c.short > 0 ? "var(--danger)" : "inherit") + '">' + (c.short > 0 ? "−" + money2(c.short) : money2(c.left)) + '</span></li>');
    const names = [...new Set(c.srcs.map(p => p.name))].join(" + ");
    return '<article class="check' + (c.short > 0 ? " short" : "") + '"><div class="check-head"><div><strong>' + dLabel(c.d) + '</strong><span class="src">' + esc(names) + '</span></div><div><span class="num">' + money2(c.gross) + '</span> ' + (c.short > 0 ? '<span class="pill warn">Short ' + money(c.short) + '</span>' : '<span class="pill">Covered</span>') + '</div></div><ul class="lines">' + lines.join("") + '</ul></article>'; }).join("");
  box.innerHTML = html;
}
document.addEventListener("change", e => { const k = e.target.dataset && e.target.dataset.paid; if (!k) return; if (e.target.checked) state.paid[k] = 1; else delete state.paid[k]; const li = e.target.closest("li"); if (li) li.classList.toggle("done", e.target.checked); state.updated = Date.now(); setPaid(k, e.target.checked); try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (err) {} renderMilestones(); });

/* ---------- dashboard ---------- */
function renderDashboard(){
  if (!$("#dashNext")) return; const pr = progressNumbers(); const sel = sims[state.strategy];
  // onboarding checklist
  const ob = $("#onboard"); const steps = [["planner.html", "Add your debts", "Balance, APR and minimum for each", state.debts.length > 0], ["paychecks.html", "Add your paydays and bills", "So every paycheck gets a plan", state.pays.length > 0], ["progress.html", "Log your balances", "Do this monthly to track real progress", state.snapshots.length > 0]];
  const allDone = steps.every(s => s[3]); if (ob){ ob.hidden = allDone; ob.querySelector(".checklist").innerHTML = steps.map((s, i) => '<a href="' + s[0] + '" class="' + (s[3] ? "done" : "") + '"><span class="n">' + (s[3] ? "✓" : i + 1) + '</span><span><strong>' + s[1] + '</strong><small>' + s[2] + '</small></span></a>').join(""); }
  // next payday
  const np = $("#dashNext"); let nextPay = null, src = null; state.pays.forEach(p => { const d = payDates(p, TODAY, addDays(TODAY, 400))[0]; if (d && (!nextPay || d < nextPay)){ nextPay = d; src = p; } });
  if (nextPay){ const days = Math.round((nextPay - TODAY) / 864e5); np.innerHTML = '<div class="days"><b>' + days + '</b><small>' + (days === 1 ? "day" : "days") + '</small></div><div><div class="big">' + dLabel(nextPay) + '</div><div class="hint" style="margin-top:0">' + esc(src.name) + ' · ' + money(n(src.amount)) + ' take-home, ' + money(n(src.amount) - n(src.spend)) + ' for bills & debt</div></div>'; }
  else np.innerHTML = '<div class="hint" style="margin:0">No paydays yet. <a href="paychecks.html">Add one</a> and your next check shows here.</div>';
  // due soon
  const ds = $("#dashDue"); const end = addDays(TODAY, 14); const items = [];
  state.bills.forEach(b => { if (n(b.amount) > 0) dueDates(b.due, TODAY, end).forEach(d => items.push({ key: "b:" + b.id + ":" + iso(d), name: b.name, amt: n(b.amount), d, type: "out" })); });
  state.debts.forEach(dt => { if (n(dt.balance) > 0 && n(dt.min) > 0) dueDates(dt.due, TODAY, end).forEach(d => items.push({ key: "d:" + dt.id + ":" + iso(d), name: dt.name + " minimum", amt: Math.min(n(dt.min), n(dt.balance)), d, type: "debt" })); });
  items.sort((a, b) => a.d - b.d);
  ds.innerHTML = items.length ? items.map(it => { const done = !!state.paid[it.key]; const days = Math.round((it.d - TODAY) / 864e5); return '<li class="' + (done ? "done" : "") + '"><input type="checkbox" data-paid="' + esc(it.key) + '"' + (done ? " checked" : "") + ' aria-label="Mark ' + esc(it.name) + ' paid"><span class="dot ' + it.type + '"></span><span class="nm">' + esc(it.name) + '</span><span class="when">' + (days === 0 ? "today" : days === 1 ? "tomorrow" : short(it.d)) + '</span><span class="amt">' + money(it.amt) + '</span></li>'; }).join("") : '<li><span class="nm" style="color:var(--muted)">Nothing due in the next two weeks.</span></li>';
  const dueTotal = items.filter(i => !state.paid[i.key]).reduce((s, i) => s + i.amt, 0); const dt = $("#dashDueTotal"); if (dt) dt.textContent = items.length ? money(dueTotal) + " still to pay" : "";
  // focus card
  const fc = $("#dashFocus");
  if (sel && !sel.stuck){ const t = state.debts.find(d => d.id === sel.order[0]); const pm = sel.payoff[t.id]; fc.innerHTML = '<div class="eyebrow">Your target right now</div><h3 style="font-size:1.3rem;margin-top:4px">' + esc(t.name) + '</h3><p class="hint" style="margin-top:4px">' + money(n(t.balance)) + ' at ' + n(t.apr) + '% APR. Send every extra dollar here' + (pm != null ? '; at this pace it’s gone by <strong>' + mLabel(sel.months[pm].date) + '</strong>.' : '.') + '</p>'; }
  else if (sel && sel.stuck) fc.innerHTML = '<div class="eyebrow">Heads up</div><p class="hint" style="margin-top:6px">Your payments don’t cover the interest yet, so the balance would grow. Add an extra monthly payment on the <a href="planner.html">Planner</a>.</p>';
  else fc.innerHTML = '<div class="eyebrow">Get started</div><p class="hint" style="margin-top:6px">Add your first debt on the <a href="planner.html">Planner</a> and your target shows here.</p>';
  const hn = $("#homeNote"); if (hn) hn.textContent = state.example ? "Showing example numbers. Open the planner to enter yours." : "";
  renderMilestones();
}

/* ---------- calendar ---------- */
let calY = TODAY.getFullYear(), calM = TODAY.getMonth();
bind("#calPrev", () => { calM--; if (calM < 0){ calM = 11; calY--; } renderCalendar(); }); bind("#calNext", () => { calM++; if (calM > 11){ calM = 0; calY++; } renderCalendar(); });
function renderCalendar(){
  const cal = $("#cal"); if (!cal) return; const first = new Date(calY, calM, 1), last = new Date(calY, calM + 1, 0); $("#calTitle").textContent = first.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  const ev = {}; const add = (d, e) => { const k = iso(d); (ev[k] = ev[k] || []).push(e); }; let inc = 0, spend = 0, bills = 0, debt = 0;
  state.pays.forEach(p => payDates(p, first, last).forEach(d => { add(d, { c: "in", t: p.name + " " + money(n(p.amount)) }); inc += n(p.amount); spend += n(p.spend); }));
  state.bills.forEach(b => { if (n(b.amount) > 0) dueDates(b.due, first, last).forEach(d => { add(d, { c: "out", t: b.name + " " + money(n(b.amount)) }); bills += n(b.amount); }); });
  state.debts.forEach(dt => { if (n(dt.balance) > 0) dueDates(dt.due, first, last).forEach(d => { add(d, { c: "debt", t: dt.name + " " + money(n(dt.min)) }); debt += n(dt.min); }); });
  let html = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(d => '<div class="dow">' + d + '</div>').join(""); const startPad = first.getDay(); const cells = Math.ceil((startPad + last.getDate()) / 7) * 7;
  for (let i = 0; i < cells; i++){ const d = new Date(calY, calM, i - startPad + 1); const inMonth = d.getMonth() === calM; const list = inMonth ? (ev[iso(d)] || []) : []; html += '<div class="day' + (inMonth ? "" : " off") + (+d === +TODAY ? " today" : "") + '" title="' + esc(list.map(e => e.t).join("\n")) + '"><span class="d">' + d.getDate() + '</span>' + list.map(e => '<span class="chip ' + e.c + '">' + esc(e.t) + '</span>').join("") + '</div>'; }
  cal.innerHTML = html; const left = inc - spend - bills - debt; const ms = $("#monthSum"); if (ms) ms.innerHTML = '<div><span>Paydays</span><b>' + money(inc) + '</b></div><div><span>Personal spending</span><b>' + money(spend) + '</b></div><div><span>Bills + debt minimums</span><b>' + money(bills + debt) + '</b></div><div><span>Left over</span><b style="color:' + (left < 0 ? "var(--danger)" : "var(--accent-ink)") + '">' + money(left) + '</b></div>';
}
bind("#exportIcs", () => {
  const end = addDays(TODAY, 365); const ev = []; const stamp = new Date().toISOString().replace(/[-:]/g, "").slice(0, 15) + "Z"; const fmt = d => iso(d).replace(/-/g, "");
  state.pays.forEach(p => payDates(p, TODAY, end).forEach(d => ev.push(["Payday: " + p.name + " " + money(n(p.amount)), d, "pay-" + p.id + "-" + fmt(d)])));
  state.bills.forEach(b => { if (n(b.amount) > 0) dueDates(b.due, TODAY, end).forEach(d => ev.push([b.name + " due " + money(n(b.amount)), d, "bill-" + b.id + "-" + fmt(d)])); });
  state.debts.forEach(dt => { if (n(dt.balance) > 0) dueDates(dt.due, TODAY, end).forEach(d => ev.push([dt.name + " payment " + money(n(dt.min)), d, "debt-" + dt.id + "-" + fmt(d)])); });
  if (!ev.length){ toast("Nothing to export yet."); return; }
  const ics = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//DebtClear//EN", "CALSCALE:GREGORIAN"].concat(...ev.map(([t, d, id]) => ["BEGIN:VEVENT", "UID:" + id + "@debtclear", "DTSTAMP:" + stamp, "DTSTART;VALUE=DATE:" + fmt(d), "DTEND;VALUE=DATE:" + fmt(addDays(d, 1)), "SUMMARY:" + t.replace(/,/g, "\\,"), "BEGIN:VALARM", "TRIGGER:-P1D", "ACTION:DISPLAY", "DESCRIPTION:" + t.replace(/,/g, "\\,"), "END:VALARM", "END:VEVENT"]), ["END:VCALENDAR"]).join("\r\n");
  download("debtclear-calendar.ics", ics, "text/calendar"); });

/* ---------- schedule ---------- */
function renderSchedule(){
  const t = $("#sched"); if (!t) return; const sel = sims[state.strategy]; const note = $("#schedNote"); if (note) note.textContent = "Month by month with " + (state.strategy === "avalanche" ? "Avalanche (highest APR first)." : "Snowball (smallest balance first).");
  if (!sel){ t.innerHTML = '<tbody><tr><td style="text-align:center;font-family:var(--body);color:var(--muted)">Add a debt to see your schedule.</td></tr></tbody>'; return; }
  const ds = sel.order.map(id => state.debts.find(d => d.id === id)); let h = '<thead><tr><th>Month</th>' + ds.map(d => '<th>' + esc(d.name) + '</th>').join("") + '<th>Interest</th><th>Still owed</th></tr></thead><tbody>';
  sel.months.forEach((r, i) => { h += '<tr><td>' + mLabel(r.date) + '</td>' + ds.map(d => { const p = r.pay[d.id]; if (p == null) return '<td class="zero">—</td>'; return '<td' + (sel.payoff[d.id] === i ? ' class="off" title="Paid off this month"' : "") + '>' + money(p) + (sel.payoff[d.id] === i ? " ✓" : "") + '</td>'; }).join("") + '<td>' + money(r.interest) + '</td><td>' + money(r.total) + '</td></tr>'; });
  if (sel.stuck) h += '<tr><td colspan="' + (ds.length + 3) + '" style="font-family:var(--body);color:var(--danger)">At these payments the balance never reaches zero. Raise a minimum or add an extra payment.</td></tr>'; t.innerHTML = h + '</tbody>';
}

/* ---------- export / backup ---------- */
function download(filename, data, type){ try { const blob = new Blob([data], { type: type || "text/plain" }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000); toast("Downloaded " + filename); } catch (e){ toast("Couldn't start the download in this browser."); } }
const csvCell = v => { const s = String(v == null ? "" : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }; const csv = rows => rows.map(r => r.map(csvCell).join(",")).join("\n");
bind("#dlBackup", () => download("debtclear-backup-" + iso(TODAY) + ".json", JSON.stringify({ app: "DebtClear", exported: new Date().toISOString(), state }, null, 2), "application/json"));
bind("#exportCsv", () => { const sel = sims[state.strategy]; if (!sel){ toast("Add a debt first."); return; } const ds = sel.order.map(id => state.debts.find(d => d.id === id)); const rows = [["Month"].concat(ds.map(d => d.name + " payment"), ds.map(d => d.name + " balance"), ["Interest", "Total owed"])];
  sel.months.forEach(r => rows.push([mLabel(r.date)].concat(ds.map(d => (r.pay[d.id] || 0).toFixed(2)), ds.map(d => (r.bal[d.id] || 0).toFixed(2)), [r.interest.toFixed(2), r.total.toFixed(2)]))); download("debtclear-schedule-" + state.strategy + ".csv", csv(rows), "text/csv"); });
bind("#exportChecks", () => { if (!checkRows.length) checkRows = buildChecks().checks; if (!checkRows.length){ toast("Add a payday first."); return; } const rows = [["Payday", "Source", "Item", "Due", "Amount"]];
  checkRows.forEach(c => { const src = c.srcs.map(p => p.name).join(" + "), dd = iso(c.d); rows.push([dd, src, "Take-home pay", "", c.gross.toFixed(2)], [dd, src, "Personal spending", "", (-c.spend).toFixed(2)]); c.items.forEach(it => rows.push([dd, src, it.name, iso(it.d), (-it.amt).toFixed(2)])); if (c.reserve > 0) rows.push([dd, src, "Set aside for later bills", "", (-c.reserve).toFixed(2)]); if (c.extra > 0) rows.push([dd, src, "Extra to " + c.target.name, "", (-c.extra).toFixed(2)]); rows.push([dd, src, c.short > 0 ? "Short" : "Left over", "", (c.short > 0 ? -c.short : c.left).toFixed(2)]); });
  download("debtclear-paycheck-plan.csv", csv(rows), "text/csv"); });
const rf = $("#restoreFile"); if (rf) rf.addEventListener("change", async e => { const f = e.target.files && e.target.files[0]; if (!f) return; try { const j = JSON.parse(await f.text()); const s = normalize(j.state || j); if (!s) throw 0; s.example = false; s.updated = Date.now(); state = s; markFull(); save(); applyTheme(); renderAll(); toast("Plan restored from " + f.name); } catch (err){ toast("That file isn't a DebtClear backup. Pick the .json file you downloaded from here."); } e.target.value = ""; });
const wipe = $("#wipe"); if (wipe) wipe.onclick = function(){ if (this.dataset.armed){ state = blankState(); markFull(); save(); renderAll(); toast("Everything erased."); delete this.dataset.armed; this.textContent = "Erase everything"; return; } this.dataset.armed = "1"; this.textContent = "Click again to erase everything"; setTimeout(() => { delete this.dataset.armed; this.textContent = "Erase everything"; }, 4000); };

/* ---------- quick entry ---------- */
let parsed = null; const num = s => parseFloat(String(s || "").replace(/[$,%\s]/g, ""));
function parseLines(text){ const out = { pays: [], bills: [], debts: [], extra: null, errors: [] };
  text.split(/\n/).forEach((raw, i) => { const line = raw.trim(); if (!line) return; const p = line.split("|").map(s => s.trim()); const kind = p[0].replace(/\*/g, "").toLowerCase(); const bad = msg => out.errors.push("Line " + (i + 1) + ": " + msg);
    if (kind === "pay"){ const a = num(p[2]); const when = String(p[3] || ""); const spend = num(p[4]) || 0; if (!p[1] || !(a > 0)){ bad("needs a name and take-home amount"); return; } const dm = when.match(/\d{4}-\d{2}-\d{2}/);
      if (dm && /bi-?weekly|every\s*(2|two)\s*weeks/i.test(when)) out.pays.push({ id: uid(), name: p[1], amount: a, freq: "biweekly", date: dm[0], days: "1, 15", spend }); else if (dm && /weekly/i.test(when)) out.pays.push({ id: uid(), name: p[1], amount: a, freq: "weekly", date: dm[0], days: "1, 15", spend }); else if (dm) out.pays.push({ id: uid(), name: p[1], amount: a, freq: "once", date: dm[0], days: "1, 15", spend });
      else { const ds = when.split(/[^0-9]+/).map(Number).filter(x => x >= 1 && x <= 31); if (!ds.length){ bad("needs pay day(s) of the month, like 1, 15"); return; } if (ds.length > 1) out.pays.push({ id: uid(), name: p[1], amount: a, freq: "twice", date: iso(TODAY), days: ds.join(", "), spend }); else out.pays.push({ id: uid(), name: p[1], amount: a, freq: "monthly", date: iso(nextOnDay(ds[0])), days: "1, 15", spend }); } }
    else if (kind === "bill"){ const a = num(p[2]), d = Math.round(num(p[3])); if (!p[1] || !(a > 0) || !(d >= 1 && d <= 31)){ bad("needs name, amount and due day"); return; } out.bills.push({ id: uid(), name: p[1], amount: a, due: d }); }
    else if (kind === "debt"){ const b = num(p[2]), apr = num(p[3]), m = num(p[4]), d = Math.round(num(p[5])) || 1; if (!p[1] || !(b >= 0) || !(apr >= 0) || !(m >= 0)){ bad("needs name, balance, APR and minimum"); return; } out.debts.push({ id: uid(), name: p[1], balance: b, start: b, apr, min: m, due: Math.min(31, d) }); }
    else if (kind === "extra"){ const a = num(p[1]); if (!(a >= 0)){ bad("needs an amount"); return; } out.extra = a; } else bad("start with Pay, Bill, Debt or Extra"); }); return out; }
const qt = $("#quickText"); if (qt) qt.addEventListener("input", e => { parsed = parseLines(e.target.value); const pv = $("#quickPreview"); const count = parsed.pays.length + parsed.bills.length + parsed.debts.length + (parsed.extra != null ? 1 : 0);
  pv.innerHTML = (count ? "<div>Ready: " + [parsed.debts.length && parsed.debts.length + " debt(s)", parsed.pays.length && parsed.pays.length + " payday(s)", parsed.bills.length && parsed.bills.length + " bill(s)", parsed.extra != null && "extra " + money(parsed.extra)].filter(Boolean).join(", ") + "</div>" : "") + parsed.errors.map(x => '<div class="bad">' + esc(x) + '</div>').join(""); $("#quickAdd").disabled = $("#quickReplace").disabled = !count; });
function applyParsed(replace){ if (!parsed) return; if (replace || state.example){ const keep = state.strategy, th = state.theme; state = blankState(); state.strategy = keep; state.theme = th; } state.debts.push(...parsed.debts); state.pays.push(...parsed.pays); state.bills.push(...parsed.bills); if (parsed.extra != null) state.extra = parsed.extra; state.updated = Date.now(); markFull(); save(); qt.value = ""; $("#quickPreview").innerHTML = ""; $("#quickAdd").disabled = $("#quickReplace").disabled = true; toast("Added to your plan."); renderAll(); }
bind("#quickAdd", () => applyParsed(false)); bind("#quickReplace", () => applyParsed(true));
bind("#copyPrompt", async () => { const prompt = "I'm setting up a debt payoff planner. Turn my notes below into lines in exactly this format, one per line, and output only the lines:\nPay | source name | take-home amount | pay days of month (e.g. 1, 15) OR 'biweekly YYYY-MM-DD' with a real pay date | personal spending per check\nBill | name | monthly amount | due day of month\nDebt | name | balance | APR % | monthly minimum | due day of month\nExtra | extra amount per month for debt\n\nMy notes:\n"; try { await navigator.clipboard.writeText(prompt); toast("Prompt copied. Paste it into any AI chat with your notes, then paste the lines back here."); } catch (e){ toast("Couldn't copy here. Use the format shown above instead."); } });

/* ---------- learn page calculators ---------- */
(function(){ const f = $("#btCalc"); if (!f) return; const run = () => { const bal = n($("#btBal").value), apr = n($("#btApr").value), fee = n($("#btFee").value), months = Math.max(1, Math.round(n($("#btMonths").value))), pay = n($("#btPay").value);
  if (!(bal > 0) || !(pay > 0)){ $("#btRes").textContent = "Fill in the numbers above."; return; } let b = bal, int = 0, m = 0; while (b > 0.005 && m < 600){ const i = b * apr / 1200; b += i; int += i; b -= Math.min(pay, b); m++; }
  let b2 = bal * (1 + fee / 100), m2 = 0, int2 = 0; while (b2 > 0.005 && m2 < 600){ const i = m2 >= months ? b2 * apr / 1200 : 0; b2 += i; int2 += i; b2 -= Math.min(pay, b2); m2++; } const cost2 = int2 + bal * fee / 100;
  $("#btRes").innerHTML = "Staying put: <b class='num'>" + money(int) + "</b> interest over " + m + " months.<br>With the transfer: <b class='num'>" + money(cost2) + "</b> (fee + interest after the promo) over " + m2 + " months. " + (int - cost2 > 0 ? "<span style='color:var(--accent-ink)'>Saves about " + money(int - cost2) + ".</span>" : "<span style='color:var(--danger)'>Costs about " + money(cost2 - int) + " more.</span>"); }; f.addEventListener("input", run); run(); })();

function renderLight(){ runSims(); renderCommon(); renderMast(); renderMeta(); renderChart(); renderWhatIf(); renderChecks(); renderCalendar(); renderSchedule(); renderDashboard(); }
function renderAll(){ runSims(); renderCommon(); renderMast(); renderInputs(); renderMeta(); renderChart(); renderWhatIf(); renderChecks(); renderCalendar(); renderSchedule(); renderDashboard(); renderProgress(); }
DC.app = { get state(){ return state; }, set displayName(v){ state.displayName = v; markDirty("profile"); save(); renderCommon(); } };
boot();
})();
